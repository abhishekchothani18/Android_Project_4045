package com.example.arraylist;



import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Arrays;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView fruitsListView = findViewById(R.id.fruitsListView);


        ArrayList<String> fruits = new ArrayList<>(Arrays.asList(
                "Apple",
                "Banana",
                "Orange",
                "Mango",
                "Grapes",
                "Strawberry",
                "Pineapple",
                "Watermelon",
                "Kiwi",
                "Papaya",
                "Guava"

        ));
        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                fruits
        );
        fruitsListView.setAdapter(adapter);
    }
}