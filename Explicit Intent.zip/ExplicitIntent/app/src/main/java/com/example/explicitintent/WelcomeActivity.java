package com.example.explicitintent;

public interface WelcomeActivity {
}
