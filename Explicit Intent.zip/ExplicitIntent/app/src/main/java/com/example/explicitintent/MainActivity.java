package com.example.explicitintent;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;
    private TextView textViewRegister;

    // Credentials for validation (in real app, this would come from database/API)
    private static final String VALID_USERNAME = "admin";
    private static final String VALID_PASSWORD = "password123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        textViewRegister = findViewById(R.id.textViewRegister);

        // Set click listener for login button
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateAndLogin();
            }
        });

        // Set click listener for register text (optional functionality)
        textViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,
                        "Register functionality would be implemented here",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void validateAndLogin() {
        // Get input values
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        // Reset errors
        editTextUsername.setError(null);
        editTextPassword.setError(null);

        // Validate inputs
        if (username.isEmpty()) {
            editTextUsername.setError("Username is required");
            editTextUsername.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            editTextPassword.setError("Password is required");
            editTextPassword.requestFocus();
            return;
        }

        if (password.length() < 6) {
            editTextPassword.setError("Password must be at least 6 characters");
            editTextPassword.requestFocus();
            return;
        }

        // Check credentials
        if (username.equals(VALID_USERNAME) && password.equals(VALID_PASSWORD)) {
            // Successful login - Create Explicit Intent
            Intent intent = new Intent(MainActivity.this, WelcomeActivity.class);

            // Pass data to WelcomeActivity using Intent extras
            intent.putExtra("USERNAME", username);
            intent.putExtra("LOGIN_TIME", System.currentTimeMillis());

            // Start WelcomeActivity
            startActivity(intent);

            // Optional: Finish login activity so user can't go back
            // finish();

        } else {
            Toast.makeText(this,
                    "Invalid credentials! Try: admin/password123",
                    Toast.LENGTH_LONG).show();
        }
    }
}