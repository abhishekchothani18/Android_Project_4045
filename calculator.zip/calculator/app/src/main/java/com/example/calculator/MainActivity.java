package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult;

    // Calculator state variables
    private String currentInput = "";
    private String firstNumber = "";
    private String secondNumber = "";
    private String currentOperator = "";
    private boolean isResultDisplayed = false;
    private boolean hasDecimal = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        tvResult = findViewById(R.id.tvResult);

        // Set up number button click listeners
        setupNumberButtons();

        // Set up operator button click listeners
        setupOperatorButtons();

        // Set up other button click listeners
        setupOtherButtons();
    }

    private void setupNumberButtons() {
        int[] numberButtonIds = {
                R.id.btnZero, R.id.btnOne, R.id.btnTwo, R.id.btnThree, R.id.btnFour,
                R.id.btnFive, R.id.btnSix, R.id.btnSeven, R.id.btnEight, R.id.btnNine
        };

        for (int buttonId : numberButtonIds) {
            Button button = findViewById(buttonId);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onNumberClick(((Button) v).getText().toString());
                }
            });
        }
    }

    private void setupOperatorButtons() {
        int[] operatorButtonIds = {
                R.id.btnAdd, R.id.btnSubtract, R.id.btnMultiply, R.id.btnDivide
        };

        for (int buttonId : operatorButtonIds) {
            Button button = findViewById(buttonId);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onOperatorClick(((Button) v).getText().toString());
                }
            });
        }
    }

    private void setupOtherButtons() {
        // Decimal button
        findViewById(R.id.btnDecimal).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onDecimalClick();
            }
        });

        // Equals button
        findViewById(R.id.btnEquals).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onEqualsClick();
            }
        });

        // Clear button
        findViewById(R.id.btnClear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClearClick();
            }
        });

        // Backspace button
        findViewById(R.id.btnBackspace).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackspaceClick();
            }
        });
    }

    private void onNumberClick(String number) {
        if (isResultDisplayed) {
            currentInput = "";
            isResultDisplayed = false;
        }

        if (currentOperator.isEmpty()) {
            // First number input
            currentInput += number;
            firstNumber = currentInput;
            updateDisplay(currentInput);
        } else {
            // Second number input
            if (secondNumber.isEmpty()) {
                currentInput = number;
            } else {
                currentInput += number;
            }
            secondNumber = currentInput;
            updateDisplay(currentInput);
        }
    }

    private void onOperatorClick(String operator) {
        if (firstNumber.isEmpty()) {
            return;
        }

        if (!secondNumber.isEmpty() && !currentOperator.isEmpty()) {
            // Calculate existing operation first
            onEqualsClick();
        }

        currentOperator = operator;
        currentInput = "";
        hasDecimal = false;
        updateDisplay(firstNumber + " " + operator);
    }

    private void onDecimalClick() {
        if (!hasDecimal) {
            if (currentInput.isEmpty()) {
                currentInput = "0.";
            } else {
                currentInput += ".";
            }

            if (currentOperator.isEmpty()) {
                firstNumber = currentInput;
            } else {
                secondNumber = currentInput;
            }

            hasDecimal = true;
            updateDisplay(currentInput);
        }
    }

    private void onEqualsClick() {
        if (firstNumber.isEmpty() || secondNumber.isEmpty() || currentOperator.isEmpty()) {
            return;
        }

        try {
            double num1 = Double.parseDouble(firstNumber);
            double num2 = Double.parseDouble(secondNumber);
            double result = 0;

            switch (currentOperator) {
                case "+":
                    result = num1 + num2;
                    break;
                case "-":
                    result = num1 - num2;
                    break;
                case "×":
                    result = num1 * num2;
                    break;
                case "÷":
                    if (num2 == 0) {
                        updateDisplay("Error: Division by zero");
                        resetCalculator();
                        return;
                    }
                    result = num1 / num2;
                    break;
            }

            // Format result
            String formattedResult = formatResult(result);

            // Set result as first number for chained operations
            firstNumber = formattedResult;
            currentInput = formattedResult;
            updateDisplay(formattedResult);

            // Reset for next operation
            secondNumber = "";
            currentOperator = "";
            isResultDisplayed = true;
            hasDecimal = formattedResult.contains(".");

        } catch (NumberFormatException e) {
            updateDisplay("Error");
            resetCalculator();
        }
    }

    private void onClearClick() {
        resetCalculator();
        updateDisplay("0");
    }

    private void onBackspaceClick() {
        if (currentInput.length() > 0) {
            // Check if we're removing a decimal point
            if (currentInput.charAt(currentInput.length() - 1) == '.') {
                hasDecimal = false;
            }

            currentInput = currentInput.substring(0, currentInput.length() - 1);

            if (currentOperator.isEmpty()) {
                firstNumber = currentInput;
            } else {
                secondNumber = currentInput;
            }

            if (currentInput.isEmpty()) {
                updateDisplay("0");
            } else {
                updateDisplay(currentInput);
            }
        }
    }

    private void updateDisplay(String text) {
        tvResult.setText(text);
    }

    private void resetCalculator() {
        currentInput = "";
        firstNumber = "";
        secondNumber = "";
        currentOperator = "";
        isResultDisplayed = false;
        hasDecimal = false;
    }

    private String formatResult(double result) {
        // Remove trailing zeros from decimal
        if (result == (long) result) {
            return String.format("%d", (long) result);
        } else {
            return String.format("%s", result);
        }
    }
}